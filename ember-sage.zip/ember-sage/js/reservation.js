/* ==========================================================================
   EMBER & SAGE — reservation.js
   Client-side validation + honest "no backend yet" submission flow.
   Architecture is ready for a future POST to a reservations API/Supabase.
   ========================================================================== */
(function(){
  "use strict";

  var form = document.getElementById("reservation-form");
  if(!form) return;

  var statusEl = form.querySelector(".form-status");
  var submitBtn = form.querySelector('button[type="submit"]');
  var successPanel = document.querySelector(".reserve-success");
  var formPanel = document.querySelector(".reserve-form-panel");

  var fields = {
    name: { el: form.querySelector("#res-name"), validate: function(v){ return v.trim().length >= 2 ? "" : "Please enter your full name."; } },
    email: { el: form.querySelector("#res-email"), validate: function(v){ return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) ? "" : "Enter a valid email address."; } },
    phone: { el: form.querySelector("#res-phone"), validate: function(v){ return /^[0-9+\-\s()]{7,}$/.test(v) ? "" : "Enter a valid phone number."; } },
    date: { el: form.querySelector("#res-date"), validate: function(v){
        if(!v) return "Please choose a date.";
        var chosen = new Date(v + "T00:00:00");
        var today = new Date(); today.setHours(0,0,0,0);
        return chosen >= today ? "" : "Please choose a future date.";
      } },
    time: { el: form.querySelector("#res-time"), validate: function(v){ return v ? "" : "Please choose a time."; } },
    guests: { el: form.querySelector("#res-guests"), validate: function(v){ return v ? "" : "Please select number of guests."; } }
  };

  // Set min date to today
  var dateInput = fields.date.el;
  if(dateInput){
    var today = new Date();
    dateInput.min = today.toISOString().split("T")[0];
  }

  function fieldWrap(el){ return el.closest(".field"); }

  function validateField(key){
    var f = fields[key];
    var msg = f.validate(f.el.value);
    var wrap = fieldWrap(f.el);
    var errorEl = wrap.querySelector(".field-error");
    wrap.classList.toggle("has-error", !!msg);
    if(errorEl) errorEl.textContent = msg;
    return !msg;
  }

  Object.keys(fields).forEach(function(key){
    fields[key].el.addEventListener("blur", function(){ validateField(key); });
  });

  form.addEventListener("submit", function(e){
    e.preventDefault();
    var allValid = true;
    Object.keys(fields).forEach(function(key){
      if(!validateField(key)) allValid = false;
    });

    if(!allValid){
      statusEl.textContent = "Please correct the highlighted fields.";
      statusEl.classList.add("error");
      var firstError = form.querySelector(".field.has-error input, .field.has-error select");
      if(firstError) firstError.focus();
      return;
    }

    statusEl.classList.remove("error");
    statusEl.textContent = "Preparing your request\u2026";
    submitBtn.setAttribute("disabled", "true");
    submitBtn.textContent = "Sending\u2026";

    // Simulated latency — this is a frontend-only demo.
    // Future integration point: POST this payload to /api/reservations (Supabase / Node / etc.)
    var payload = {
      name: fields.name.el.value.trim(),
      email: fields.email.el.value.trim(),
      phone: fields.phone.el.value.trim(),
      date: fields.date.el.value,
      time: fields.time.el.value,
      guests: fields.guests.el.value,
      request: form.querySelector("#res-request") ? form.querySelector("#res-request").value.trim() : ""
    };

    setTimeout(function(){
      submitBtn.removeAttribute("disabled");
      submitBtn.textContent = "Request a Table";
      statusEl.textContent = "";
      showSuccess(payload);
    }, 900);
  });

  function formatDate(iso){
    var d = new Date(iso + "T00:00:00");
    return d.toLocaleDateString(undefined, { weekday:"long", year:"numeric", month:"long", day:"numeric" });
  }

  function showSuccess(payload){
    if(!successPanel) return;
    successPanel.querySelector("[data-res-name]").textContent = payload.name;
    successPanel.querySelector("[data-res-date]").textContent = formatDate(payload.date);
    successPanel.querySelector("[data-res-time]").textContent = payload.time;
    successPanel.querySelector("[data-res-guests]").textContent = payload.guests + (payload.guests === "1" ? " Guest" : " Guests");

    if(formPanel) formPanel.style.display = "none";
    successPanel.classList.add("show");
    successPanel.setAttribute("tabindex", "-1");
    successPanel.focus();
    successPanel.scrollIntoView({ behavior: "smooth", block: "start" });
  }
})();
