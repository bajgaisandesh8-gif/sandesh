/* ==========================================================================
   EMBER & SAGE — menu.js
   Full menu data, category filtering, live search, and detail modal.
   ========================================================================== */
(function(){
  "use strict";

  var IMG = "assets/images/"; // relative to /menu.html at project root

  // Menu items live in one place so restaurant data is easy to update.
  var MENU = [
    { id:1, name:"Charred Peach & Burrata", cat:"starters", price:"NPR 780", desc:"Torched local peaches, burrata, basil oil, aged balsamic.", ingredients:"Peaches, burrata, basil, balsamic, pink peppercorn.", tags:["Vegetarian"], rec:false, img:"dish-05.jpg" },
    { id:2, name:"Smoked Trout Tartare", cat:"starters", price:"NPR 950", desc:"Himalayan trout, crème fraîche, pickled shallot, rye crisp.", ingredients:"Trout, crème fraîche, shallot, dill, rye.", tags:["Chef's Special"], rec:true, img:"dish-06.jpg" },
    { id:3, name:"Ember Roasted Beets", cat:"starters", price:"NPR 690", desc:"Slow-roasted beets, whipped goat cheese, hazelnut, thyme.", ingredients:"Beetroot, goat cheese, hazelnut, thyme oil.", tags:["Vegetarian","Gluten-Free"], rec:false, img:"dish-07.jpg" },

    { id:4, name:"Roasted Squash Soup", cat:"soups", price:"NPR 620", desc:"Brown butter squash, sage crisp, toasted pepitas.", ingredients:"Squash, sage, cream, pepitas.", tags:["Vegetarian"], rec:false, img:"dish-08.jpg" },
    { id:5, name:"Charred Little Gem Salad", cat:"soups", price:"NPR 710", desc:"Grilled gem lettuce, anchovy dressing, parmesan, sourdough crumb.", ingredients:"Little gem, anchovy, parmesan, sourdough.", tags:[], rec:false, img:"dish-09.jpg" },
    { id:6, name:"Heirloom Tomato & Sage", cat:"soups", price:"NPR 740", desc:"Estate tomatoes, fried sage, whipped ricotta, olive oil.", ingredients:"Tomato, sage, ricotta, olive oil.", tags:["Vegetarian","Gluten-Free"], rec:false, img:"dish-10.jpg" },

    { id:7, name:"Ember-Grilled Tenderloin", cat:"mains", price:"NPR 2,450", desc:"Charred vegetables, smoked jus, seasonal herbs.", ingredients:"Beef tenderloin, root vegetables, smoked jus, herbs.", tags:["Chef's Special"], rec:true, img:"dish-01.jpg" },
    { id:8, name:"Saffron Risotto", cat:"vegetarian", price:"NPR 1,480", desc:"Wild mushrooms, parmesan, herb oil.", ingredients:"Arborio rice, saffron, wild mushroom, parmesan.", tags:["Vegetarian"], rec:false, img:"dish-02.jpg" },
    { id:9, name:"Himalayan Herb-Crusted Salmon", cat:"seafood", price:"NPR 2,100", desc:"Roasted vegetables, lemon beurre blanc.", ingredients:"Salmon, herb crust, seasonal vegetables, lemon beurre blanc.", tags:["Gluten-Free"], rec:false, img:"dish-03.jpg" },
    { id:10, name:"Truffle Forest Pasta", cat:"vegetarian", price:"NPR 1,650", desc:"Wild mushrooms, parmesan, truffle cream.", ingredients:"Hand-cut pasta, wild mushroom, truffle cream, parmesan.", tags:["Vegetarian","Chef's Special"], rec:true, img:"dish-04.jpg" },
    { id:11, name:"Charcoal Grilled Prawns", cat:"seafood", price:"NPR 1,980", desc:"Chili-lime glaze, coconut rice, coriander.", ingredients:"Tiger prawns, chili, lime, coconut rice.", tags:["Spicy","Gluten-Free"], rec:false, img:"dish-11.jpg" },
    { id:12, name:"Fire-Roasted Cauliflower", cat:"vegetarian", price:"NPR 1,180", desc:"Whole roasted cauliflower, romesco, almond, herb.", ingredients:"Cauliflower, romesco, almond, herbs.", tags:["Vegan","Gluten-Free"], rec:false, img:"dish-12.jpg" },
    { id:13, name:"Slow-Braised Lamb Shank", cat:"mains", price:"NPR 2,650", desc:"Root vegetable mash, red wine jus, gremolata.", ingredients:"Lamb shank, root vegetable, red wine jus.", tags:["Chef's Special"], rec:false, img:"dish-13.jpg" },
    { id:14, name:"Seared Himalayan Trout", cat:"seafood", price:"NPR 1,890", desc:"Brown butter, capers, charred lemon, greens.", ingredients:"Trout, brown butter, capers, lemon.", tags:["Gluten-Free"], rec:false, img:"dish-14.jpg" },

    { id:15, name:"Ember Chocolate Tart", cat:"desserts", price:"NPR 720", desc:"Dark chocolate, sea salt, vanilla cream.", ingredients:"Dark chocolate, sea salt, vanilla bean cream.", tags:["Vegetarian"], rec:true, img:"dish-15.jpg" },
    { id:16, name:"Sage Citrus Cheesecake", cat:"desserts", price:"NPR 680", desc:"Citrus curd, sage sugar, almond crumble.", ingredients:"Cream cheese, citrus curd, sage sugar, almond.", tags:["Vegetarian"], rec:false, img:"dish-16.jpg" },
    { id:17, name:"Charred Fig & Honey Panna Cotta", cat:"desserts", price:"NPR 650", desc:"Local honey, charred fig, toasted pistachio.", ingredients:"Cream, honey, fig, pistachio.", tags:["Vegetarian","Gluten-Free"], rec:false, img:"dish-17.jpg" },

    { id:18, name:"Ember Old Fashioned", cat:"beverages", price:"NPR 890", desc:"Smoked bourbon, demerara, orange bitters.", ingredients:"Bourbon, demerara, bitters, orange.", tags:[], rec:false, img:"dish-18.jpg" },
    { id:19, name:"Sage & Citrus Spritz", cat:"beverages", price:"NPR 650", desc:"Gin, sage cordial, grapefruit, soda.", ingredients:"Gin, sage cordial, grapefruit, soda.", tags:["Vegetarian"], rec:false, img:"dish-19.jpg" },
    { id:20, name:"House Roasted Coffee", cat:"beverages", price:"NPR 380", desc:"Single-origin, roasted in-house, served black or with cream.", ingredients:"Single-origin coffee beans.", tags:["Vegan"], rec:false, img:"dish-20.jpg" }
  ];

  var CAT_LABELS = {
    starters:"Starters", soups:"Soups & Salads", mains:"Main Course",
    vegetarian:"Vegetarian", seafood:"Seafood", desserts:"Desserts", beverages:"Beverages"
  };

  var listEl = document.querySelector(".menu-list");
  if(!listEl) return; // menu.js only runs on menu.html

  var emptyEl = document.querySelector(".menu-empty");
  var searchInput = document.querySelector(".menu-search input");
  var filterBtns = document.querySelectorAll(".menu-filters button");
  var activeCat = "all";
  var activeQuery = "";

  function tagClass(tag){
    if(tag === "Vegetarian" || tag === "Vegan") return "tag veg";
    if(tag === "Spicy") return "tag spicy";
    if(tag === "Chef's Special") return "tag special";
    return "tag";
  }

  function render(){
    listEl.innerHTML = MENU.map(function(item){
      return (
        '<article class="menu-row" data-cat="' + item.cat + '" data-name="' + item.name.toLowerCase() + '" tabindex="0" role="button" aria-haspopup="dialog" data-id="' + item.id + '">' +
          '<div class="thumb img-frame"><img src="' + IMG + item.img + '" alt="" loading="lazy" onerror="this.closest(\'.thumb\').style.background=\'linear-gradient(135deg,#2a241c,#17130e)\'; this.remove();"></div>' +
          '<div class="menu-row-body">' +
            '<div class="menu-row-top"><h3>' + item.name + '</h3><span class="dish-price">' + item.price + '</span></div>' +
            '<p class="dish-desc">' + item.desc + '</p>' +
            '<div class="dish-tags">' + item.tags.map(function(t){ return '<span class="' + tagClass(t) + '">' + t + '</span>'; }).join("") + '</div>' +
          '</div>' +
        '</article>'
      );
    }).join("");

    listEl.querySelectorAll(".menu-row").forEach(function(row){
      row.addEventListener("click", function(){ openModal(Number(row.dataset.id)); });
      row.addEventListener("keydown", function(e){
        if(e.key === "Enter" || e.key === " "){ e.preventDefault(); openModal(Number(row.dataset.id)); }
      });
    });

    applyFilters();
  }

  function applyFilters(){
    var visibleCount = 0;
    listEl.querySelectorAll(".menu-row").forEach(function(row){
      var matchesCat = activeCat === "all" || row.dataset.cat === activeCat;
      var matchesQuery = !activeQuery || row.dataset.name.indexOf(activeQuery) !== -1;
      var show = matchesCat && matchesQuery;
      row.classList.toggle("filtered-out", !show);
      if(show) visibleCount++;
    });
    if(emptyEl) emptyEl.classList.toggle("show", visibleCount === 0);
  }

  filterBtns.forEach(function(btn){
    btn.addEventListener("click", function(){
      filterBtns.forEach(function(b){ b.setAttribute("aria-pressed","false"); });
      btn.setAttribute("aria-pressed","true");
      activeCat = btn.dataset.filter;
      applyFilters();
    });
  });

  if(searchInput){
    searchInput.addEventListener("input", function(){
      activeQuery = searchInput.value.trim().toLowerCase();
      applyFilters();
    });
  }

  /* ---------------- Modal ---------------- */
  var overlay = document.querySelector(".modal-overlay");
  var modalBody = overlay ? overlay.querySelector(".modal-body") : null;
  var modalMedia = overlay ? overlay.querySelector(".modal-media") : null;
  var lastFocused = null;

  function openModal(id){
    var item = MENU.filter(function(m){ return m.id === id; })[0];
    if(!item || !overlay) return;
    lastFocused = document.activeElement;

    modalMedia.innerHTML = '<img src="' + IMG + item.img + '" alt="' + item.name + '" onerror="this.style.display=\'none\';">';
    modalBody.innerHTML =
      '<button class="modal-close" aria-label="Close dish details">' +
        '<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M1 1L15 15M15 1L1 15" stroke="currentColor" stroke-width="1.4"/></svg>' +
      '</button>' +
      '<span class="eyebrow">' + CAT_LABELS[item.cat] + '</span>' +
      '<h3>' + item.name + '</h3>' +
      '<span class="modal-price">' + item.price + '</span>' +
      '<p class="dish-desc">' + item.desc + '</p>' +
      '<div class="dish-tags">' + item.tags.map(function(t){ return '<span class="' + tagClass(t) + '">' + t + '</span>'; }).join("") + '</div>' +
      '<p class="modal-ingredients"><strong>Ingredients:</strong> ' + item.ingredients + '</p>' +
      (item.rec ? '<p class="modal-rec">Chef\u2019s recommendation \u2014 a guest favorite, prepared as Chef Aarav intends it.</p>' : '');

    overlay.classList.add("open");
    overlay.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";
    overlay.querySelector(".modal-close").addEventListener("click", closeModal);
    overlay.querySelector(".modal-close").focus();
  }

  function closeModal(){
    overlay.classList.remove("open");
    overlay.setAttribute("aria-hidden", "true");
    document.body.style.overflow = "";
    if(lastFocused) lastFocused.focus();
  }

  if(overlay){
    overlay.addEventListener("click", function(e){
      if(e.target === overlay) closeModal();
    });
    document.addEventListener("keydown", function(e){
      if(e.key === "Escape" && overlay.classList.contains("open")) closeModal();
    });
  }

  render();
})();
