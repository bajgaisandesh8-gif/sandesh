/* ==========================================================================
   EMBER & SAGE — main.js
   Site-wide behavior: loader, navigation, custom cursor, scroll reveal,
   scroll progress, footer newsletter, page transitions.
   ========================================================================== */
(function(){
  "use strict";

  var prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var isTouch = window.matchMedia("(hover: none)").matches;

  /* ---------------- Loader ---------------- */
  window.addEventListener("load", function(){
    var loader = document.getElementById("loader");
    if(!loader) return;
    var delay = prefersReducedMotion ? 0 : 600;
    setTimeout(function(){
      loader.classList.add("hidden");
      document.body.classList.remove("no-scroll");
    }, delay);
  });

  /* ---------------- Navigation scroll state ---------------- */
  var nav = document.querySelector(".site-nav");
  function onScrollNav(){
    if(!nav) return;
    if(window.scrollY > 40) nav.classList.add("scrolled");
    else nav.classList.remove("scrolled");
  }
  document.addEventListener("scroll", onScrollNav, { passive:true });
  onScrollNav();

  /* ---------------- Scroll progress bar ---------------- */
  var progressBar = document.querySelector(".scroll-progress");
  function onScrollProgress(){
    if(!progressBar) return;
    var h = document.documentElement;
    var scrolled = h.scrollTop;
    var max = h.scrollHeight - h.clientHeight;
    var pct = max > 0 ? (scrolled / max) * 100 : 0;
    progressBar.style.width = pct + "%";
  }
  document.addEventListener("scroll", onScrollProgress, { passive:true });
  onScrollProgress();

  /* ---------------- Mobile menu ---------------- */
  var hamburger = document.querySelector(".hamburger");
  var mobileMenu = document.querySelector(".mobile-menu");
  if(hamburger && mobileMenu){
    hamburger.addEventListener("click", function(){
      var expanded = hamburger.getAttribute("aria-expanded") === "true";
      hamburger.setAttribute("aria-expanded", String(!expanded));
      mobileMenu.classList.toggle("open", !expanded);
      document.body.style.overflow = !expanded ? "hidden" : "";
      if(!expanded){
        var firstLink = mobileMenu.querySelector("a");
        if(firstLink) firstLink.focus();
      }
    });
    mobileMenu.addEventListener("keydown", function(e){
      if(e.key === "Escape"){
        hamburger.setAttribute("aria-expanded", "false");
        mobileMenu.classList.remove("open");
        document.body.style.overflow = "";
        hamburger.focus();
      }
    });
    mobileMenu.querySelectorAll("a").forEach(function(a){
      a.addEventListener("click", function(){
        hamburger.setAttribute("aria-expanded", "false");
        mobileMenu.classList.remove("open");
        document.body.style.overflow = "";
      });
    });
  }

  /* ---------------- Custom cursor (desktop only) ---------------- */
  if(!isTouch && !prefersReducedMotion){
    var dot = document.createElement("div");
    dot.className = "cursor-dot";
    dot.setAttribute("aria-hidden", "true");
    document.body.appendChild(dot);
    var mx = 0, my = 0, cx = 0, cy = 0;
    document.addEventListener("mousemove", function(e){
      mx = e.clientX; my = e.clientY;
      dot.style.opacity = "1";
    });
    (function raf(){
      cx += (mx - cx) * 0.35;
      cy += (my - cy) * 0.35;
      dot.style.transform = "translate(" + cx + "px," + cy + "px) translate(-50%,-50%)";
      requestAnimationFrame(raf);
    })();
    var hoverTargets = "a, button, .g-item, .carousel-card, input, textarea, select, [data-cursor-hover]";
    document.addEventListener("mouseover", function(e){
      var t = e.target.closest ? e.target.closest(hoverTargets) : null;
      if(t){
        dot.classList.add("hover");
        dot.classList.toggle("view", !!t.closest(".g-item"));
      }
    });
    document.addEventListener("mouseout", function(e){
      var t = e.target.closest ? e.target.closest(hoverTargets) : null;
      if(t){ dot.classList.remove("hover"); dot.classList.remove("view"); }
    });
    document.addEventListener("mouseleave", function(){ dot.style.opacity = "0"; });
  }

  /* ---------------- Image fallback: never let a missing photo break layout --- */
  function handleImgFallback(img){
    var frame = img.closest(".img-frame, .thumb");
    if(frame){ frame.classList.add("img-fallback"); }
    else { img.style.display = "none"; } // parent art-bg / gradient shows through instead
  }
  // Capture-phase listener: catches error events from images added later too
  // (e.g. menu.js / gallery.js render content after this script runs).
  document.addEventListener("error", function(e){
    if(e.target && e.target.tagName === "IMG"){ handleImgFallback(e.target); }
  }, true);
  document.querySelectorAll("img").forEach(function(img){
    if(img.complete && img.naturalWidth === 0){ handleImgFallback(img); }
  });

  /* ---------------- Ember particles — signature ambient motion ---------------- */
  document.querySelectorAll(".ember-canvas").forEach(function(canvas){
    if(prefersReducedMotion) return;
    var ctx = canvas.getContext("2d");
    var particles = [];
    var count = isTouch ? 14 : 26;
    function resize(){
      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
    }
    function spawn(){
      return {
        x: Math.random() * canvas.width,
        y: canvas.height + Math.random() * 40,
        r: Math.random() * 1.8 + 0.6,
        speed: Math.random() * 0.5 + 0.25,
        drift: (Math.random() - 0.5) * 0.4,
        glow: Math.random() > 0.5 ? "rgba(217,145,95," : "rgba(124,138,99,",
        alpha: Math.random() * 0.6 + 0.3,
        life: Math.random() * 200
      };
    }
    resize();
    window.addEventListener("resize", resize);
    for(var i=0;i<count;i++){ var p = spawn(); p.y = Math.random() * canvas.height; particles.push(p); }
    function tick(){
      if(!canvas.isConnected) return;
      ctx.clearRect(0,0,canvas.width, canvas.height);
      particles.forEach(function(p){
        p.y -= p.speed;
        p.x += p.drift;
        p.life++;
        var fade = Math.max(0, 1 - p.y / canvas.height * 0.15);
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI*2);
        ctx.fillStyle = p.glow + (p.alpha * fade) + ")";
        ctx.shadowBlur = 6;
        ctx.shadowColor = p.glow + "0.8)";
        ctx.fill();
        if(p.y < -10){
          var np = spawn();
          p.x = np.x; p.y = canvas.height + 10; p.r = np.r; p.speed = np.speed; p.drift = np.drift; p.glow = np.glow; p.alpha = np.alpha;
        }
      });
      requestAnimationFrame(tick);
    }
    tick();
  });

  /* ---------------- Scroll reveal (IntersectionObserver) ---------------- */
  var revealEls = document.querySelectorAll("[data-reveal]");
  if("IntersectionObserver" in window && revealEls.length){
    var io = new IntersectionObserver(function(entries){
      entries.forEach(function(entry){
        if(entry.isIntersecting){
          entry.target.classList.add("in-view");
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15, rootMargin: "0px 0px -8% 0px" });
    revealEls.forEach(function(el){ io.observe(el); });
  } else {
    revealEls.forEach(function(el){ el.classList.add("in-view"); });
  }

  /* ---------------- Auto-stagger reveal delays within groups ---------------- */
  document.querySelectorAll("[data-reveal-group]").forEach(function(group){
    var children = group.querySelectorAll("[data-reveal]");
    children.forEach(function(child, i){
      child.style.transitionDelay = (i * 90) + "ms";
    });
  });

  /* ---------------- Footer newsletter (frontend-only, honest messaging) ---------------- */
  var newsletterForm = document.querySelector(".newsletter-form");
  if(newsletterForm){
    newsletterForm.addEventListener("submit", function(e){
      e.preventDefault();
      var input = newsletterForm.querySelector("input");
      var btn = newsletterForm.querySelector("button");
      if(!input.value || !input.validity.valid){
        input.focus();
        return;
      }
      var original = btn.textContent;
      btn.textContent = "Thank you";
      input.value = "";
      setTimeout(function(){ btn.textContent = original; }, 2600);
    });
  }

  /* ---------------- Active nav link ---------------- */
  var path = window.location.pathname.split("/").pop() || "index.html";
  document.querySelectorAll(".nav-links a, .mobile-menu a").forEach(function(a){
    var href = a.getAttribute("href");
    if(href === path || (path === "" && href === "index.html")){
      a.setAttribute("aria-current", "page");
    }
  });

  /* ---------------- Subtle page-load transition wipe ---------------- */
  if(!prefersReducedMotion){
    var wipe = document.createElement("div");
    wipe.className = "page-transition animate-in";
    document.body.appendChild(wipe);
    setTimeout(function(){ wipe.remove(); }, 650);

    document.querySelectorAll('a[href$=".html"]').forEach(function(link){
      if(link.target === "_blank" || link.hasAttribute("download")) return;
      link.addEventListener("click", function(e){
        var href = link.getAttribute("href");
        if(!href || href.startsWith("#")) return;
        var sameOrigin = link.hostname === window.location.hostname;
        if(!sameOrigin) return;
        e.preventDefault();
        var out = document.createElement("div");
        out.className = "page-transition animate-out";
        document.body.appendChild(out);
        setTimeout(function(){ window.location.href = href; }, 480);
      });
    });
  }

})();
