/* ==========================================================================
   EMBER & SAGE — slider.js
   Hero parallax + cinematic slider, 3D carousel, draggable strip,
   signature showcase scroll-scale, "From Earth to Table" scroll story.
   ========================================================================== */
(function(){
  "use strict";
  var prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var isTouch = window.matchMedia("(hover: none)").matches;

  /* ============================================================
     HERO — layered parallax + auto-rotating slide captions
     ============================================================ */
  var hero = document.querySelector(".hero");
  if(hero){
    var bg = hero.querySelector(".hero-bg");
    var atmos = hero.querySelector(".hero-atmos");
    var content = hero.querySelector(".hero-content");
    var fg = hero.querySelector(".hero-foreground");

    if(!isTouch && !prefersReducedMotion){
      hero.addEventListener("mousemove", function(e){
        var rect = hero.getBoundingClientRect();
        var px = (e.clientX - rect.left) / rect.width - 0.5;
        var py = (e.clientY - rect.top) / rect.height - 0.5;
        if(bg) bg.style.transform = "scale(1.08) translate3d(" + (px * -14) + "px," + (py * -10) + "px,0)";
        if(atmos) atmos.style.transform = "translate3d(" + (px * 24) + "px," + (py * 18) + "px,0)";
        if(content) content.style.transform = "translate3d(" + (px * 8) + "px," + (py * 5) + "px,0)";
        if(fg) fg.style.transform = "translate3d(" + (px * -30) + "px," + (py * -20) + "px,0) rotate3d(0,1,0," + (px*4) + "deg)";
      });
      hero.addEventListener("mouseleave", function(){
        [bg, atmos, content, fg].forEach(function(el){ if(el) el.style.transform = ""; });
      });
    }

    // Slide metadata cycling (label/title in hero corresponds to "slides")
    var slides = [
      { label: "Restaurant Interior", },
      { label: "Signature Dish" },
      { label: "Executive Chef" },
      { label: "Dining Atmosphere" }
    ];
    var metaEls = hero.querySelectorAll(".hero-slidemeta span");
    var dots = hero.querySelectorAll(".hero-dots button");
    var current = 0;
    function showSlide(i){
      metaEls.forEach(function(el, idx){ el.classList.toggle("active", idx === i); });
      dots.forEach(function(d, idx){ d.setAttribute("aria-current", idx === i ? "true" : "false"); });
      current = i;
    }
    if(metaEls.length){
      showSlide(0);
      if(!prefersReducedMotion){
        var heroTimer = setInterval(function(){
          showSlide((current + 1) % metaEls.length);
        }, 4200);
        hero.addEventListener("mouseenter", function(){ clearInterval(heroTimer); });
      }
      dots.forEach(function(d, idx){
        d.addEventListener("click", function(){ showSlide(idx); });
      });
    }
  }

  /* ============================================================
     3D CAROUSEL — "The Taste of Ember"
     ============================================================ */
  var stage = document.querySelector(".carousel-stage");
  if(stage){
    var cards = Array.prototype.slice.call(stage.querySelectorAll(".carousel-card"));
    var counterEl = document.querySelector(".carousel-counter");
    var progressEl = document.querySelector(".carousel-progress span");
    var total = cards.length;
    var index = 0;
    var autoplayId = null;
    var isInteracting = false;

    function layout(){
      cards.forEach(function(card, i){
        var offset = i - index;
        // normalize offset to shortest path around the loop
        if(offset > total / 2) offset -= total;
        if(offset < -total / 2) offset += total;

        var abs = Math.abs(offset);
        var tx = offset * 62; // % translateX
        var tz = -abs * 220;
        var ry = offset * -28;
        var scale = 1 - abs * 0.18;
        var opacity = abs > 2 ? 0 : 1 - abs * 0.32;
        var z = 100 - abs;

        card.style.transform = "translate(-50%,-50%) translateX(" + tx + "%) translateZ(" + tz + "px) rotateY(" + ry + "deg) scale(" + Math.max(scale,0.5) + ")";
        card.style.opacity = String(Math.max(opacity, 0));
        card.style.zIndex = String(z);
        card.style.pointerEvents = abs > 2 ? "none" : "auto";
        card.classList.toggle("is-active", offset === 0);
      });
      if(counterEl){
        counterEl.textContent = String(index + 1).padStart(2,"0") + " / " + String(total).padStart(2,"0");
      }
    }

    function go(dir){
      index = (index + dir + total) % total;
      layout();
      restartProgress();
    }

    function restartProgress(){
      if(!progressEl) return;
      progressEl.style.transition = "none";
      progressEl.style.transform = "scaleX(0)";
      // force reflow
      void progressEl.offsetWidth;
      if(!prefersReducedMotion && !isInteracting){
        progressEl.style.transition = "transform 5s linear";
        progressEl.style.transform = "scaleX(1)";
      }
    }

    function startAutoplay(){
      if(prefersReducedMotion) return;
      stopAutoplay();
      restartProgress();
      autoplayId = setInterval(function(){ go(1); }, 5000);
    }
    function stopAutoplay(){
      if(autoplayId){ clearInterval(autoplayId); autoplayId = null; }
      if(progressEl){ progressEl.style.transition = "none"; progressEl.style.transform = "scaleX(0)"; }
    }

    document.querySelectorAll("[data-carousel-prev]").forEach(function(b){ b.addEventListener("click", function(){ isInteracting = true; go(-1); }); });
    document.querySelectorAll("[data-carousel-next]").forEach(function(b){ b.addEventListener("click", function(){ isInteracting = true; go(1); }); });

    cards.forEach(function(card, i){
      card.addEventListener("click", function(){
        if(i !== index){ isInteracting = true; index = i; layout(); restartProgress(); }
      });
    });

    stage.setAttribute("tabindex", "0");
    stage.setAttribute("role", "region");
    stage.setAttribute("aria-label", "Signature dish carousel");
    stage.addEventListener("keydown", function(e){
      if(e.key === "ArrowLeft"){ isInteracting = true; go(-1); }
      if(e.key === "ArrowRight"){ isInteracting = true; go(1); }
    });

    // drag / swipe
    var startX = 0, dragging = false, dragged = 0;
    function dragStart(x){ dragging = true; startX = x; dragged = 0; isInteracting = true; stopAutoplay(); }
    function dragMove(x){ if(dragging) dragged = x - startX; }
    function dragEnd(){
      if(!dragging) return;
      dragging = false;
      if(dragged > 40) go(-1);
      else if(dragged < -40) go(1);
      startAutoplay();
    }
    stage.addEventListener("mousedown", function(e){ dragStart(e.clientX); });
    window.addEventListener("mousemove", function(e){ dragMove(e.clientX); });
    window.addEventListener("mouseup", dragEnd);
    stage.addEventListener("touchstart", function(e){ dragStart(e.touches[0].clientX); }, { passive:true });
    stage.addEventListener("touchmove", function(e){ dragMove(e.touches[0].clientX); }, { passive:true });
    stage.addEventListener("touchend", dragEnd);

    stage.addEventListener("mouseenter", function(){ isInteracting = true; stopAutoplay(); });
    stage.addEventListener("mouseleave", function(){ isInteracting = false; startAutoplay(); });
    stage.addEventListener("focusin", function(){ isInteracting = true; stopAutoplay(); });
    stage.addEventListener("focusout", function(){ isInteracting = false; startAutoplay(); });

    layout();
    startAutoplay();
  }

  /* ============================================================
     DRAGGABLE IMAGE STRIP
     ============================================================ */
  var stripWrap = document.querySelector(".strip-wrap");
  if(stripWrap){
    var track = stripWrap.querySelector(".strip-track");
    var isDown = false, startXs = 0, scrollLeftStart = 0;

    stripWrap.addEventListener("mousedown", function(e){
      isDown = true;
      stripWrap.classList.add("dragging");
      startXs = e.pageX - stripWrap.offsetLeft;
      scrollLeftStart = stripWrap.scrollLeft;
    });
    window.addEventListener("mouseup", function(){ isDown = false; stripWrap.classList.remove("dragging"); });
    stripWrap.addEventListener("mouseleave", function(){ isDown = false; stripWrap.classList.remove("dragging"); });
    stripWrap.addEventListener("mousemove", function(e){
      if(!isDown) return;
      e.preventDefault();
      var x = e.pageX - stripWrap.offsetLeft;
      var walk = (x - startXs) * 1.2;
      stripWrap.scrollLeft = scrollLeftStart - walk;
    });

    // subtle 3D tilt per item based on distance from strip center
    if(!isTouch && !prefersReducedMotion){
      function tiltItems(){
        var rect = stripWrap.getBoundingClientRect();
        var center = rect.left + rect.width / 2;
        stripWrap.querySelectorAll(".strip-item").forEach(function(item){
          var ir = item.getBoundingClientRect();
          var dist = (ir.left + ir.width/2 - center) / rect.width;
          item.style.transform = "perspective(900px) rotateY(" + (dist * -10) + "deg) scale(" + (1 - Math.min(Math.abs(dist),0.5)*0.08) + ")";
        });
      }
      stripWrap.addEventListener("scroll", function(){ requestAnimationFrame(tiltItems); }, { passive:true });
      tiltItems();
    }
  }

  /* ============================================================
     SIGNATURE SHOWCASE — scroll scale/reveal
     ============================================================ */
  var showcase = document.querySelector(".showcase");
  if(showcase){
    var media = showcase.querySelector(".showcase-media img");
    function onShowcaseScroll(){
      var rect = showcase.getBoundingClientRect();
      var vh = window.innerHeight;
      var progress = Math.min(Math.max((0 - rect.top) / (rect.height - vh), 0), 1);
      if(media && !prefersReducedMotion){
        var scale = 1.15 - progress * 0.15;
        media.style.transform = "scale(" + scale + ")";
      }
      showcase.classList.toggle("reveal", rect.top < vh * 0.5);
    }
    document.addEventListener("scroll", onShowcaseScroll, { passive:true });
    onShowcaseScroll();
  }

  /* ============================================================
     FROM EARTH TO TABLE — sticky horizontal scroll story
     ============================================================ */
  var etPin = document.querySelector(".et-pin");
  if(etPin){
    var etTrack = etPin.querySelector(".et-track");
    var etStages = etPin.querySelectorAll(".et-stage");
    var etProgress = etPin.querySelectorAll(".et-progress span");
    var stageCount = etStages.length;

    function onEtScroll(){
      var rect = etPin.getBoundingClientRect();
      var total = rect.height - window.innerHeight;
      var progress = Math.min(Math.max(-rect.top / total, 0), 1);
      var travel = (stageCount - 1) * 100; // percent of one stage-width per step
      var xPercent = progress * travel;
      if(etTrack){
        etTrack.style.transform = "translateX(-" + xPercent + "%)";
      }
      var activeIdx = Math.min(Math.floor(progress * stageCount), stageCount - 1);
      etProgress.forEach(function(p, i){
        p.classList.toggle("active", i === activeIdx);
        p.classList.toggle("done", i < activeIdx);
      });
    }
    document.addEventListener("scroll", onEtScroll, { passive:true });
    window.addEventListener("resize", onEtScroll);
    onEtScroll();
  }

})();
