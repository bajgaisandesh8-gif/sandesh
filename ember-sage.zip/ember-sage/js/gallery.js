/* ==========================================================================
   EMBER & SAGE — gallery.js
   Fullscreen lightbox for the gallery page: prev/next, ESC, swipe, keyboard.
   ========================================================================== */
(function(){
  "use strict";

  var grid = document.querySelector(".gallery-grid");
  var lightbox = document.querySelector(".lightbox");
  if(!grid || !lightbox) return;

  var items = Array.prototype.slice.call(grid.querySelectorAll(".g-item"));
  var imgEl = lightbox.querySelector("img");
  var capEl = lightbox.querySelector(".lightbox-cap");
  var counterEl = lightbox.querySelector(".lightbox-counter");
  var closeBtn = lightbox.querySelector(".lightbox-close");
  var prevBtn = lightbox.querySelector(".lightbox-prev");
  var nextBtn = lightbox.querySelector(".lightbox-next");
  var index = 0;
  var lastFocused = null;

  function open(i){
    index = i;
    lastFocused = document.activeElement;
    update();
    lightbox.classList.add("open");
    lightbox.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";
    closeBtn.focus();
  }
  function close(){
    lightbox.classList.remove("open");
    lightbox.setAttribute("aria-hidden", "true");
    document.body.style.overflow = "";
    if(lastFocused) lastFocused.focus();
  }
  function update(){
    var srcImg = items[index].querySelector("img");
    imgEl.style.opacity = "0";
    setTimeout(function(){
      imgEl.src = srcImg.src;
      imgEl.alt = srcImg.alt || "";
      imgEl.style.opacity = "1";
    }, 120);
    if(capEl) capEl.textContent = srcImg.alt || "";
    if(counterEl) counterEl.textContent = String(index + 1).padStart(2,"0") + " / " + String(items.length).padStart(2,"0");
  }
  function go(dir){
    index = (index + dir + items.length) % items.length;
    update();
  }

  items.forEach(function(item, i){
    var btn = item.querySelector("button");
    if(btn) btn.addEventListener("click", function(){ open(i); });
  });

  closeBtn.addEventListener("click", close);
  prevBtn.addEventListener("click", function(){ go(-1); });
  nextBtn.addEventListener("click", function(){ go(1); });
  lightbox.addEventListener("click", function(e){ if(e.target === lightbox) close(); });

  document.addEventListener("keydown", function(e){
    if(!lightbox.classList.contains("open")) return;
    if(e.key === "Escape") close();
    if(e.key === "ArrowLeft") go(-1);
    if(e.key === "ArrowRight") go(1);
  });

  // touch swipe
  var touchStartX = 0;
  lightbox.addEventListener("touchstart", function(e){ touchStartX = e.touches[0].clientX; }, { passive:true });
  lightbox.addEventListener("touchend", function(e){
    var dx = e.changedTouches[0].clientX - touchStartX;
    if(dx > 50) go(-1);
    else if(dx < -50) go(1);
  });

  /* 3D hover tilt on grid images */
  var isTouch = window.matchMedia("(hover: none)").matches;
  var prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  if(!isTouch && !prefersReducedMotion){
    items.forEach(function(item){
      item.addEventListener("mousemove", function(e){
        var rect = item.getBoundingClientRect();
        var px = (e.clientX - rect.left) / rect.width - 0.5;
        var py = (e.clientY - rect.top) / rect.height - 0.5;
        var img = item.querySelector("img");
        img.style.transform = "scale(1.07) rotateX(" + (py * -6) + "deg) rotateY(" + (px * 6) + "deg)";
      });
      item.addEventListener("mouseleave", function(){
        item.querySelector("img").style.transform = "";
      });
    });
  }
})();
